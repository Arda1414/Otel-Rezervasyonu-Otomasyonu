﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Otel_Rezervazsyonu_Otomasyonu
{
    public partial class Yonetici : Form
    {
        public Yonetici()
        {
            InitializeComponent();
        }

        private void BTNgeri_Click(object sender, EventArgs e)
        {
            HesapSecimi frm = new HesapSecimi();
            frm.Show();
            this.Hide();
        }

        public SqlCommand cmd;
        public SqlDataReader oku;
        bool deneme;
        private void BTNgiris_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection())
                {
                    con.ConnectionString = "Data Source=Localhost;Initial Catalog=OtelRezervasyonuOtomasyonu;User ID=sa;Password=123456";
                    con.Open();

                    // Kullanıcı girişi kontrolü
                    string sorgu = "SELECT * FROM Personeller WHERE Personel_Kad=@Personel_Kad AND Personel_sifre=@Personel_sifre";
                    using (SqlCommand cmd = new SqlCommand(sorgu, con))
                    {
                        cmd.Parameters.AddWithValue("@Personel_Kad", TXTkad.Text);
                        cmd.Parameters.AddWithValue("@Personel_sifre", TXTsifre.Text);

                        using (SqlDataReader oku = cmd.ExecuteReader())
                        {
                            if (oku.Read())
                            {
                                deneme = true;
                            }
                            else
                            {
                                MessageBox.Show("Kullanıcı adı veya şifre hatalı!");
                            }
                        }
                    }

                    // Yönetici kontrolü
                    string kontrolSorgu = "SELECT * FROM Personeller WHERE Personel_gorevi = @Personel_gorevi";
                    using (SqlCommand kontrolCmd = new SqlCommand(kontrolSorgu, con))
                    {
                        kontrolCmd.Parameters.AddWithValue("@Personel_gorevi", "Yönetici");

                        using (SqlDataReader kontrolOku = kontrolCmd.ExecuteReader())
                        {
                            if (kontrolOku.Read() && deneme)
                            {
                                // Yönetici olarak giriş yapıldı
                                string mesaj = "Hoşgeldin ";
                                MessageBox.Show(mesaj);
                                YoneticiEkran frm = new YoneticiEkran();
                                frm.Show();
                                Hide();
                            }
                        }
                    }

                    con.Close();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
    }
}
