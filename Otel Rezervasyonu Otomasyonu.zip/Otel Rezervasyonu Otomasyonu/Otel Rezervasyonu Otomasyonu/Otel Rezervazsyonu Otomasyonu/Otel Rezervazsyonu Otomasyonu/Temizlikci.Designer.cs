﻿namespace Otel_Rezervazsyonu_Otomasyonu
{
    partial class Temizlikci
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Temizlikci));
            pictureBox1 = new PictureBox();
            BTNgiris = new Button();
            TXTsifre = new TextBox();
            TXTkad = new TextBox();
            label2 = new Label();
            label1 = new Label();
            BTNgeri = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-3, -7);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(354, 455);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 22;
            pictureBox1.TabStop = false;
            // 
            // BTNgiris
            // 
            BTNgiris.Location = new Point(443, 276);
            BTNgiris.Name = "BTNgiris";
            BTNgiris.Size = new Size(94, 29);
            BTNgiris.TabIndex = 21;
            BTNgiris.Text = "GİRİŞ YAP";
            BTNgiris.UseVisualStyleBackColor = true;
            BTNgiris.Click += BTNgiris_Click;
            // 
            // TXTsifre
            // 
            TXTsifre.Location = new Point(491, 184);
            TXTsifre.Name = "TXTsifre";
            TXTsifre.Size = new Size(125, 27);
            TXTsifre.TabIndex = 20;
            // 
            // TXTkad
            // 
            TXTkad.Location = new Point(491, 136);
            TXTkad.Name = "TXTkad";
            TXTkad.Size = new Size(125, 27);
            TXTkad.TabIndex = 19;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(417, 184);
            label2.Name = "label2";
            label2.Size = new Size(74, 23);
            label2.TabIndex = 18;
            label2.Text = "Şifreniz :";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.Location = new Point(357, 135);
            label1.Name = "label1";
            label1.Size = new Size(134, 23);
            label1.TabIndex = 17;
            label1.Text = "Kullanıcı Adınız :";
            // 
            // BTNgeri
            // 
            BTNgeri.Location = new Point(490, 387);
            BTNgeri.Name = "BTNgeri";
            BTNgeri.Size = new Size(94, 29);
            BTNgeri.TabIndex = 23;
            BTNgeri.Text = "Geri Dön";
            BTNgeri.UseVisualStyleBackColor = true;
            BTNgeri.Click += BTNgeri_Click;
            // 
            // Temizlikci
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(633, 450);
            Controls.Add(BTNgeri);
            Controls.Add(pictureBox1);
            Controls.Add(BTNgiris);
            Controls.Add(TXTsifre);
            Controls.Add(TXTkad);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Temizlikci";
            Text = "Temizlikci";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Button BTNgiris;
        private TextBox TXTsifre;
        private TextBox TXTkad;
        private Label label2;
        private Label label1;
        private Button BTNgeri;
    }
}