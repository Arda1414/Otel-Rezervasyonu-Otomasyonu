﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Otel_Rezervazsyonu_Otomasyonu
{
    public partial class TemizlenenOdalar : Form
    {
        public TemizlenenOdalar()
        {
            InitializeComponent();
        }

        private void btnGeri_Click(object sender, EventArgs e)
        {
            if (HesapSecimi.oncekiForm == "Temizlikçi")
            {
                TemizlikciEkran frm = new TemizlikciEkran();
                frm.Show();
                Hide();
            }
            else
            {
                YoneticiEkran frm = new YoneticiEkran();
                frm.Show();
                Hide();
            }
        }

        private void TemizlenenOdalar_Load(object sender, EventArgs e)
        {
            gridDoldur();
        }
        void gridDoldur()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "Server=localhost; Database=OtelRezervasyonuOtomasyonu; User Id=sa; Password=123456;";

            try
            {
                con.Open();

                string sorgu = "SELECT * FROM Odalar WHERE Durumu=@Deger";
                SqlCommand cmd = new SqlCommand(sorgu, con);
                cmd.Parameters.AddWithValue("@Deger", "Temizlendi");

                SqlDataAdapter da = new SqlDataAdapter(cmd); 
                DataSet ds = new DataSet();
                da.Fill(ds, "Odalar");
                dataGridView1.DataSource = ds.Tables["Odalar"];
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Hata:" + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

    }
}
