﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Otel_Rezervazsyonu_Otomasyonu
{
    public partial class YoneticiEkran : Form
    {
        public YoneticiEkran()
        {
            InitializeComponent();
        }

        private void BTNMekle_Click(object sender, EventArgs e)
        {
            MusteriEkle frm = new MusteriEkle();
            frm.Show();
            this.Hide();
        }

        private void BTNMsil_Click(object sender, EventArgs e)
        {
            MusteriSil frm = new MusteriSil();
            frm.Show();
            this.Hide();
        }

        private void BTNMguncelle_Click(object sender, EventArgs e)
        {
            MusteriGuncelle frm = new MusteriGuncelle();
            frm.Show();
            this.Hide();
        }

        private void BTNMlistele_Click(object sender, EventArgs e)
        {
            MusteriListele frm = new MusteriListele();
            frm.Show();
            this.Hide();
        }

        private void BTNPlistele_Click(object sender, EventArgs e)
        {
            PersonelListele frm = new PersonelListele();
            frm.Show();
            this.Hide();
        }

        private void BTNPekle_Click(object sender, EventArgs e)
        {
            PersonelEkle frm = new PersonelEkle();
            frm.Show();
            this.Hide();
        }

        private void BTNPsil_Click(object sender, EventArgs e)
        {
            PersonelSil frm = new PersonelSil();
            frm.Show();
            this.Hide();
        }

        private void BTNPguncelle_Click(object sender, EventArgs e)
        {
            PersonelGuncelle frm = new PersonelGuncelle();
            frm.Show();
            this.Hide();
        }

        private void BTNgelirgor_Click(object sender, EventArgs e)
        {
            AylikGelirGider frm = new AylikGelirGider();
            frm.Show();
            this.Hide();
        }

        private void BTNgelirekle_Click(object sender, EventArgs e)
        {
            AylıkGelirGiderEkleme frm = new AylıkGelirGiderEkleme();
            frm.Show();
            this.Hide();
        }

        private void BTNodaekle_Click(object sender, EventArgs e)
        {
            OdaEkle frm = new OdaEkle();
            frm.Show();
            this.Hide();
        }

        private void BTNodasil_Click(object sender, EventArgs e)
        {
            OdaSil frm = new OdaSil();
            frm.Show();
            this.Hide();
        }

        private void BTNodaguncelle_Click(object sender, EventArgs e)
        {
            OdaGuncelle frm = new OdaGuncelle();
            frm.Show();
            this.Hide();
        }

        private void BTNodalistele_Click(object sender, EventArgs e)
        {
            OdalariListele frm = new OdalariListele();
            frm.Show();
            this.Hide();
        }

        private void BTNodagor_Click(object sender, EventArgs e)
        {
            TemizlenenOdalar frm = new TemizlenenOdalar();
            frm.Show();
            this.Hide();
        }
    }
}
