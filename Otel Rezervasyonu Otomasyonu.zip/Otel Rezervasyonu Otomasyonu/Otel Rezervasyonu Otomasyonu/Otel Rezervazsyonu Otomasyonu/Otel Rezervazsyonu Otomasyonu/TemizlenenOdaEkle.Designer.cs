﻿namespace Otel_Rezervazsyonu_Otomasyonu
{
    partial class TemizlenenOdaEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TemizlenenOdaEkle));
            pictureBox1 = new PictureBox();
            label1 = new Label();
            cbOdaAd = new ComboBox();
            button1 = new Button();
            btnGeri = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-1, -26);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(310, 248);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 58;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(324, 44);
            label1.Name = "label1";
            label1.Size = new Size(137, 19);
            label1.TabIndex = 59;
            label1.Text = "Temizlenen Oda Adı :";
            // 
            // cbOdaAd
            // 
            cbOdaAd.FormattingEnabled = true;
            cbOdaAd.Location = new Point(479, 44);
            cbOdaAd.Margin = new Padding(3, 2, 3, 2);
            cbOdaAd.Name = "cbOdaAd";
            cbOdaAd.Size = new Size(133, 23);
            cbOdaAd.TabIndex = 60;
            cbOdaAd.SelectedIndexChanged += cbOdaAd_SelectedIndexChanged;
            // 
            // button1
            // 
            button1.Location = new Point(458, 95);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(82, 22);
            button1.TabIndex = 61;
            button1.Text = "EKLE";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnGeri
            // 
            btnGeri.Location = new Point(467, 152);
            btnGeri.Name = "btnGeri";
            btnGeri.Size = new Size(75, 23);
            btnGeri.TabIndex = 62;
            btnGeri.Text = "Geri Dön";
            btnGeri.UseVisualStyleBackColor = true;
            btnGeri.Click += btnGeri_Click;
            // 
            // TemizlenenOdaEkle
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(658, 220);
            Controls.Add(btnGeri);
            Controls.Add(button1);
            Controls.Add(cbOdaAd);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "TemizlenenOdaEkle";
            Text = "TemizlenenOdaEkle";
            Load += TemizlenenOdaEkle_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private ComboBox cbOdaAd;
        private Button button1;
        private Button btnGeri;
    }
}