﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Otel_Rezervazsyonu_Otomasyonu
{
    public partial class TemizlenenOdaEkle : Form
    {
        public TemizlenenOdaEkle()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Değişiklikleri yapmaya eminmisiniz", "Uyarı", MessageBoxButtons.OKCancel);
            if (result == DialogResult.OK)
            {
                SqlConnection con = new SqlConnection();
                SqlCommand cmd = new SqlCommand();
                con.ConnectionString = "Server localhost; Database OtelRezervasyonuOtomasyonu; User Id sa; Password 123456;";
                con.Open();

                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "UPDATE Odalar SET Durumu=True)";


                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Eklendi");

                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Hata:" + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void cbOdaAd_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void TemizlenenOdaEkle_Load(object sender, EventArgs e)
        {
            cbDoldur();
        }
        void cbDoldur()
        {
            SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            con = new SqlConnection();
            con.ConnectionString = "Server = localhost; Database=OtelRezervasyonuOtomasyonu; User Id = sa; Password = 123456;";
            try

            {
                con.Open();
            }

            catch (SqlException ex)
            {
                MessageBox.Show("Hata:" + ex.Message);
            }

            finally
            {
                string sorgu = "SELECT Oda_adi FROM Odalar";
                cmd = new SqlCommand(sorgu, con); SqlDataReader oku = cmd.ExecuteReader();
                while (oku.Read())
                {
                    cbOdaAd.Items.Add(oku[0]);
                }
                con.Close();
            }

        }

        private void btnGeri_Click(object sender, EventArgs e)
        {
            TemizlikciEkran frm = new TemizlikciEkran();
            Hide();
            frm.Show();
        }
    }
}
