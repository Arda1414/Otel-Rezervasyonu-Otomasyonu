﻿namespace Otel_Rezervazsyonu_Otomasyonu
{
    partial class Yonetici
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Yonetici));
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            TXTkad = new TextBox();
            TXTsifre = new TextBox();
            BTNgiris = new Button();
            BTNgeri = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(1, 0);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(297, 338);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(301, 77);
            label1.Name = "label1";
            label1.Size = new Size(106, 19);
            label1.TabIndex = 1;
            label1.Text = "Kullanıcı Adınız :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(354, 114);
            label2.Name = "label2";
            label2.Size = new Size(59, 19);
            label2.TabIndex = 2;
            label2.Text = "Şifreniz :";
            // 
            // TXTkad
            // 
            TXTkad.Location = new Point(418, 78);
            TXTkad.Margin = new Padding(3, 2, 3, 2);
            TXTkad.Name = "TXTkad";
            TXTkad.Size = new Size(110, 23);
            TXTkad.TabIndex = 3;
            // 
            // TXTsifre
            // 
            TXTsifre.Location = new Point(418, 114);
            TXTsifre.Margin = new Padding(3, 2, 3, 2);
            TXTsifre.Name = "TXTsifre";
            TXTsifre.Size = new Size(110, 23);
            TXTsifre.TabIndex = 4;
            // 
            // BTNgiris
            // 
            BTNgiris.Location = new Point(376, 191);
            BTNgiris.Margin = new Padding(3, 2, 3, 2);
            BTNgiris.Name = "BTNgiris";
            BTNgiris.Size = new Size(82, 22);
            BTNgiris.TabIndex = 5;
            BTNgiris.Text = "GİRİŞ YAP";
            BTNgiris.UseVisualStyleBackColor = true;
            BTNgiris.Click += BTNgiris_Click;
            // 
            // BTNgeri
            // 
            BTNgeri.Location = new Point(304, 305);
            BTNgeri.Margin = new Padding(3, 2, 3, 2);
            BTNgeri.Name = "BTNgeri";
            BTNgeri.Size = new Size(82, 22);
            BTNgeri.TabIndex = 6;
            BTNgeri.Text = "Geri Dön";
            BTNgeri.UseVisualStyleBackColor = true;
            BTNgeri.Click += BTNgeri_Click;
            // 
            // Yonetici
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(571, 338);
            Controls.Add(BTNgeri);
            Controls.Add(BTNgiris);
            Controls.Add(TXTsifre);
            Controls.Add(TXTkad);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Yonetici";
            Text = "Yonetici";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private Label label2;
        private TextBox TXTkad;
        private TextBox TXTsifre;
        private Button BTNgiris;
        private Button BTNgeri;
    }
}