﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Otel_Rezervazsyonu_Otomasyonu
{
    public partial class TemizlikciEkran : Form
    {
        public TemizlikciEkran()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TemizlenenOdaEkle frm = new TemizlenenOdaEkle();
            frm.Show();
            Hide();
        }

        private void TemizlikciEkran_Load(object sender, EventArgs e)
        {
            HesapSecimi.oncekiForm = "Temizlikçi";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TemizlenenOdalar frm=new TemizlenenOdalar();
            frm.Show();
            Hide();
        }
    }
}
