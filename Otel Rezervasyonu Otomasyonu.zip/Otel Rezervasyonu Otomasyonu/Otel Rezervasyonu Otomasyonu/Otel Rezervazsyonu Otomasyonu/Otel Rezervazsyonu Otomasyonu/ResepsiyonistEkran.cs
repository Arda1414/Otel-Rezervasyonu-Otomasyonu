﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Otel_Rezervazsyonu_Otomasyonu
{
    public partial class ResepsiyonistEkran : Form
    {
        public ResepsiyonistEkran()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            MusteriEkle frm = new MusteriEkle();
            frm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MusteriSil frm = new MusteriSil();
            frm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MusteriGuncelle frm = new MusteriGuncelle();
            frm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MusteriListele frm = new MusteriListele();
            frm.Show();
            this.Hide();


        }

        private void ResepsiyonistEkran_Load(object sender, EventArgs e)
        {
            HesapSecimi.oncekiForm = "Resepsiyonist";
        }
    }
}
