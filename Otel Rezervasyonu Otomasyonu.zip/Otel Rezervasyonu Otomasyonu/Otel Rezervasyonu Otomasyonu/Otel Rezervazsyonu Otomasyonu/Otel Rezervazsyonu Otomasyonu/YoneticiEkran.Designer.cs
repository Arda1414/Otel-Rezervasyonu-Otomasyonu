﻿namespace Otel_Rezervazsyonu_Otomasyonu
{
    partial class YoneticiEkran
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YoneticiEkran));
            pictureBox1 = new PictureBox();
            BTNMekle = new Button();
            BTNMsil = new Button();
            BTNMguncelle = new Button();
            BTNMlistele = new Button();
            BTNgelirgor = new Button();
            BTNPlistele = new Button();
            BTNPguncelle = new Button();
            BTNPsil = new Button();
            BTNPekle = new Button();
            BTNgelirekle = new Button();
            BTNodagor = new Button();
            BTNodaekle = new Button();
            BTNodalistele = new Button();
            BTNodasil = new Button();
            BTNodaguncelle = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-1, -2);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(294, 346);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 22;
            pictureBox1.TabStop = false;
            // 
            // BTNMekle
            // 
            BTNMekle.Location = new Point(327, 59);
            BTNMekle.Margin = new Padding(3, 2, 3, 2);
            BTNMekle.Name = "BTNMekle";
            BTNMekle.Size = new Size(164, 22);
            BTNMekle.TabIndex = 23;
            BTNMekle.Text = "MÜŞTERİ EKLE";
            BTNMekle.UseVisualStyleBackColor = true;
            BTNMekle.Click += BTNMekle_Click;
            // 
            // BTNMsil
            // 
            BTNMsil.Location = new Point(327, 102);
            BTNMsil.Margin = new Padding(3, 2, 3, 2);
            BTNMsil.Name = "BTNMsil";
            BTNMsil.Size = new Size(164, 22);
            BTNMsil.TabIndex = 24;
            BTNMsil.Text = "MÜŞTERİ SİL";
            BTNMsil.UseVisualStyleBackColor = true;
            BTNMsil.Click += BTNMsil_Click;
            // 
            // BTNMguncelle
            // 
            BTNMguncelle.Location = new Point(327, 147);
            BTNMguncelle.Margin = new Padding(3, 2, 3, 2);
            BTNMguncelle.Name = "BTNMguncelle";
            BTNMguncelle.Size = new Size(164, 22);
            BTNMguncelle.TabIndex = 25;
            BTNMguncelle.Text = "MÜŞTERİ GÜNCELLE";
            BTNMguncelle.UseVisualStyleBackColor = true;
            BTNMguncelle.Click += BTNMguncelle_Click;
            // 
            // BTNMlistele
            // 
            BTNMlistele.Location = new Point(327, 188);
            BTNMlistele.Margin = new Padding(3, 2, 3, 2);
            BTNMlistele.Name = "BTNMlistele";
            BTNMlistele.Size = new Size(164, 22);
            BTNMlistele.TabIndex = 26;
            BTNMlistele.Text = "MÜŞTERİ LİSTELE";
            BTNMlistele.UseVisualStyleBackColor = true;
            BTNMlistele.Click += BTNMlistele_Click;
            // 
            // BTNgelirgor
            // 
            BTNgelirgor.Location = new Point(499, 188);
            BTNgelirgor.Margin = new Padding(3, 2, 3, 2);
            BTNgelirgor.Name = "BTNgelirgor";
            BTNgelirgor.Size = new Size(161, 22);
            BTNgelirgor.TabIndex = 27;
            BTNgelirgor.Text = "AYLIK GELİR GİDERİ GÖR";
            BTNgelirgor.UseVisualStyleBackColor = true;
            BTNgelirgor.Click += BTNgelirgor_Click;
            // 
            // BTNPlistele
            // 
            BTNPlistele.Location = new Point(327, 235);
            BTNPlistele.Margin = new Padding(3, 2, 3, 2);
            BTNPlistele.Name = "BTNPlistele";
            BTNPlistele.Size = new Size(164, 22);
            BTNPlistele.TabIndex = 28;
            BTNPlistele.Text = "ELEMANLARI LİSTELE";
            BTNPlistele.UseVisualStyleBackColor = true;
            BTNPlistele.Click += BTNPlistele_Click;
            // 
            // BTNPguncelle
            // 
            BTNPguncelle.Location = new Point(496, 147);
            BTNPguncelle.Margin = new Padding(3, 2, 3, 2);
            BTNPguncelle.Name = "BTNPguncelle";
            BTNPguncelle.Size = new Size(164, 22);
            BTNPguncelle.TabIndex = 31;
            BTNPguncelle.Text = "ELEMAN GÜNCELLE";
            BTNPguncelle.UseVisualStyleBackColor = true;
            BTNPguncelle.Click += BTNPguncelle_Click;
            // 
            // BTNPsil
            // 
            BTNPsil.Location = new Point(496, 102);
            BTNPsil.Margin = new Padding(3, 2, 3, 2);
            BTNPsil.Name = "BTNPsil";
            BTNPsil.Size = new Size(164, 22);
            BTNPsil.TabIndex = 30;
            BTNPsil.Text = "ELEMAN SİL";
            BTNPsil.UseVisualStyleBackColor = true;
            BTNPsil.Click += BTNPsil_Click;
            // 
            // BTNPekle
            // 
            BTNPekle.Location = new Point(496, 59);
            BTNPekle.Margin = new Padding(3, 2, 3, 2);
            BTNPekle.Name = "BTNPekle";
            BTNPekle.Size = new Size(164, 22);
            BTNPekle.TabIndex = 29;
            BTNPekle.Text = "ELEMAN EKLE";
            BTNPekle.UseVisualStyleBackColor = true;
            BTNPekle.Click += BTNPekle_Click;
            // 
            // BTNgelirekle
            // 
            BTNgelirekle.Location = new Point(499, 235);
            BTNgelirekle.Margin = new Padding(3, 2, 3, 2);
            BTNgelirekle.Name = "BTNgelirekle";
            BTNgelirekle.Size = new Size(161, 22);
            BTNgelirekle.TabIndex = 32;
            BTNgelirekle.Text = "AYLIK GELİR GİDER EKLE";
            BTNgelirekle.UseVisualStyleBackColor = true;
            BTNgelirekle.Click += BTNgelirekle_Click;
            // 
            // BTNodagor
            // 
            BTNodagor.Location = new Point(327, 276);
            BTNodagor.Margin = new Padding(3, 2, 3, 2);
            BTNodagor.Name = "BTNodagor";
            BTNodagor.Size = new Size(330, 22);
            BTNodagor.TabIndex = 33;
            BTNodagor.Text = "TEMİZLENEN ODALARI GÖR";
            BTNodagor.UseVisualStyleBackColor = true;
            BTNodagor.Click += BTNodagor_Click;
            // 
            // BTNodaekle
            // 
            BTNodaekle.Location = new Point(665, 59);
            BTNodaekle.Margin = new Padding(3, 2, 3, 2);
            BTNodaekle.Name = "BTNodaekle";
            BTNodaekle.Size = new Size(164, 22);
            BTNodaekle.TabIndex = 34;
            BTNodaekle.Text = "Oda Ekle";
            BTNodaekle.UseVisualStyleBackColor = true;
            BTNodaekle.Click += BTNodaekle_Click;
            // 
            // BTNodalistele
            // 
            BTNodalistele.Location = new Point(665, 188);
            BTNodalistele.Margin = new Padding(3, 2, 3, 2);
            BTNodalistele.Name = "BTNodalistele";
            BTNodalistele.Size = new Size(164, 22);
            BTNodalistele.TabIndex = 35;
            BTNodalistele.Text = "Odaları Listele";
            BTNodalistele.UseVisualStyleBackColor = true;
            BTNodalistele.Click += BTNodalistele_Click;
            // 
            // BTNodasil
            // 
            BTNodasil.Location = new Point(665, 102);
            BTNodasil.Margin = new Padding(3, 2, 3, 2);
            BTNodasil.Name = "BTNodasil";
            BTNodasil.Size = new Size(164, 22);
            BTNodasil.TabIndex = 36;
            BTNodasil.Text = "Oda Sil";
            BTNodasil.UseVisualStyleBackColor = true;
            BTNodasil.Click += BTNodasil_Click;
            // 
            // BTNodaguncelle
            // 
            BTNodaguncelle.Location = new Point(665, 147);
            BTNodaguncelle.Margin = new Padding(3, 2, 3, 2);
            BTNodaguncelle.Name = "BTNodaguncelle";
            BTNodaguncelle.Size = new Size(164, 22);
            BTNodaguncelle.TabIndex = 37;
            BTNodaguncelle.Text = "Oda Güncelle";
            BTNodaguncelle.UseVisualStyleBackColor = true;
            BTNodaguncelle.Click += BTNodaguncelle_Click;
            // 
            // YoneticiEkran
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(842, 342);
            Controls.Add(BTNodaguncelle);
            Controls.Add(BTNodasil);
            Controls.Add(BTNodalistele);
            Controls.Add(BTNodaekle);
            Controls.Add(BTNodagor);
            Controls.Add(BTNgelirekle);
            Controls.Add(BTNPguncelle);
            Controls.Add(BTNPsil);
            Controls.Add(BTNPekle);
            Controls.Add(BTNPlistele);
            Controls.Add(BTNgelirgor);
            Controls.Add(BTNMlistele);
            Controls.Add(BTNMguncelle);
            Controls.Add(BTNMsil);
            Controls.Add(BTNMekle);
            Controls.Add(pictureBox1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "YoneticiEkran";
            Text = "YoneticiEkran";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private Button BTNMekle;
        private Button BTNMsil;
        private Button BTNMguncelle;
        private Button BTNMlistele;
        private Button BTNgelirgor;
        private Button BTNPlistele;
        private Button BTNPguncelle;
        private Button BTNPsil;
        private Button BTNPekle;
        private Button BTNgelirekle;
        private Button BTNodagor;
        private Button BTNodaekle;
        private Button BTNodalistele;
        private Button BTNodasil;
        private Button BTNodaguncelle;
    }
}